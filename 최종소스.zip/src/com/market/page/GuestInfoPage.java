package com.market.page;
import javax.swing.*;
import java.awt.*;
import com.market.member.UserInIt;

public class GuestInfoPage extends JPanel {
    public GuestInfoPage(JPanel panel) {
        Font ft;
        ft = new Font("함초롬돋움", Font.BOLD, 15);
        setLayout(null);
        Rectangle rect = panel.getBounds();
        System.out.println(rect);
        setPreferredSize(rect.getSize());

        // ✅ 구글 이름
        JPanel namePanel = new JPanel();
        namePanel.setBounds(0, 100, 1000, 50);
        add(namePanel);
        JLabel nameLabel = new JLabel("구글 이름 : ");
        nameLabel.setFont(ft);
        JLabel nameField = new JLabel();
        nameField.setText(UserInIt.getmUser().getName());
        nameField.setFont(ft);
        namePanel.add(nameLabel);
        namePanel.add(nameField);

        // ✅ 구글 이메일
        JPanel emailPanel = new JPanel();
        emailPanel.setBounds(0, 150, 1000, 100);
        add(emailPanel);
        JLabel emailLabel = new JLabel("구글 이메일 : ");
        emailLabel.setFont(ft);
        JLabel emailField = new JLabel();
        emailField.setText(UserInIt.getmUser().getPhone()); // 이메일이 phone 필드에 저장됨
        emailField.setFont(ft);
        emailPanel.add(emailLabel);
        emailPanel.add(emailField);
    }

    public static void main(String[] args) {
        JFrame frame = new JFrame();
        frame.setBounds(0, 0, 1000, 750);
        frame.setLayout(null);
        JPanel mPagePanel = new JPanel();
        mPagePanel.setBounds(0, 150, 1000, 750);
        frame.add(mPagePanel);
        mPagePanel.add("고객 정보 확인하기", new GuestInfoPage(mPagePanel));
        frame.setVisible(true);
    }
}